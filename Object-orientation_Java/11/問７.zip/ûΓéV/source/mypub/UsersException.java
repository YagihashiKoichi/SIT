package	mypub;
public	class UsersException	extends	Exception{
	public	UsersException(String	str){
		super(str);
	}
}